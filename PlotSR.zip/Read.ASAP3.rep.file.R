# Function to read and extract fields from ASAP3 rep files
# Original code written by Adrien Tableau
# Modified from "fish-delay_test.R" by Jeremy Collie on 6-Jun-23
# Modified on 8-Jun-23 to read the reference points

read.ASAP3.rep.file <- function(rep.file='2017_FLW_GB_VPA_ASAP.rep') {
  tmp=readLines(rep.file)
  # readLines reads text from a connection as character text 

  tmp=tmp[tmp!=""]       # remove blank fields
# index the fields that are needed by their line numbers 
index=lapply(c(
  "F Reference Points Using Final Year Selectivity and Freport options",
  'Stock-Recruitment Relationship Parameters',
  'Spawning Stock, Obs Recruits(year+1), Pred Recruits(year+1), standardized residual',
  'Annual stock recruitment parameters',
  ' fleet 1 selectivity at age',
  ' fleet 2 selectivity at age',
  'Fmult by year for each fleet',
  'Directed F by age and year for each fleet',
  'Population Numbers at the Start of the Year',
  'Biomass Time Series','q by index'),function(x)which(tmp==x))
index=do.call(c,index[as.vector(lengths(index)==1)])  # unlist the index
#do.call constructs and executes a function call from a name or a function and a list of arguments to be passed to it.

# now construct the needed objects, indexed by their line numbers
# convert SR data to SSB in thousand tonnes, R in millions
SR=do.call(rbind.data.frame,lapply(strsplit(tmp[(index[3]+1):(index[4]-1)],' '),function(x)x[x!=''][1:3]))[-1,];names(SR)=c('year','SSB','R')
#Split the elements of a character vector x into and convert them to a data frame.
SR=apply(SR,1:2,as.character)           # convert to character to search for strings
SR[SR[,]%in%c("init","xxxx","NA")]=NA   # replace strings with NA
SR=data.frame(apply(SR,1:2,as.numeric)) # convert back to numeric
SR[,2]=0.001*SR[,2]                     # SSB in thousand tonnes
SR[,3]=0.001*SR[,3]                     # R in millions
SR=SR[-nrow(SR),]                       # omit the last year 

# Numbers per age
Na=do.call(rbind.data.frame,lapply(strsplit(tmp[(index[8]+1):(index[9]-1)],' '),function(x)as.numeric(x[-1])))
# Scale numbers from thousands to millions
Na <- Na*1e-3
names(Na)=1:ncol(Na)

# Fishing mortality
FF=do.call(rbind.data.frame,lapply(strsplit(tmp[(index[6]+1):(index[7]-1)],' '),function(x)as.numeric(x[x!=''])))
if(ncol(FF)==3){FF[,2]=rowSums(FF[,2:3])}
names(FF)=c('year','F')

# selectivity
selec=do.call(rbind.data.frame,lapply(strsplit(tmp[(index[5]+1):(index[6]-1)],' '),function(x)as.numeric(x[-1])));names(selec)=1:ncol(selec)

# Stock-Recruitment Relationship Parameters
SRparam=do.call(rbind.data.frame,lapply(strsplit(tmp[(index[2]+1):(index[3]-1)],' '),function(x)x[x!=''][c(1,3)]))[-1,]
names(SRparam)=c('parameter','value')
SRparam$value=as.numeric(SRparam$value)

# F reference points
Fref=do.call(rbind.data.frame,lapply(strsplit(tmp[(index[1]+1):(index[2]-1)],' '),function(x)x[x!=''][c(1:3,5,7)]))[-1,]
names(Fref)=c('refpt','F','slope','SSBmsy','MSY')
Fref$F=as.numeric(Fref$F)
Fref$slope=as.numeric(Fref$slope)
Fref$SSBmsy=as.numeric(Fref$SSBmsy)*0.001
Fref$MSY=as.numeric(Fref$MSY)*0.001
# note that the reference points will be character variables

# Biomass Time Series
Biomass=do.call(rbind.data.frame,lapply(strsplit(tmp[(index[9]+1):(index[10]-1)],' '),function(x)x[x!=''][c(1,3)]))[-1,]
names(Biomass)=c('Year','SSB')
Biomass$SSB=as.numeric(Biomass$SSB)*0.001

# combine the extracted objects in a list
result <- list(SR=SR,Na=Na,FF=FF,selec=selec,Fref=Fref,SRparam=SRparam,Biomass=Biomass)
}
