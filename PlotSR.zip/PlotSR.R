# Task 1. Analyze the time series of recruitment and spawning stock biomass
# Written by Jeremy Collie on 6-June-23
# Revised by Jeremy Collie on 13-Jul-23 to update ricker function
######################################################################
# Step 1: Gather the input files
######################################################################
#rm(list=ls())
setwd("C:/Users/Jerem/Documents/Research/NOAA_COCA/Stock Assessments/WhiteHake/Analyses")
source("Read.ASAP3.rep.file.R")
whk.2022 <- read.ASAP3.rep.file(rep.file="RUN14.rep")
whk.2022$SR$Lnrs <- with(whk.2022$SR, log(R/SSB))
whk.2019 <- read.ASAP3.rep.file(rep.file="2019_HKW_UNIT_MODEL_BASE.rep")
whk.2019$SR$Lnrs <- with(whk.2019$SR, log(R/SSB))
whk.2017 <- read.ASAP3.rep.file(rep.file="2017_HKW_UNIT_MOD.rep")
whk.2017$SR$Lnrs <- with(whk.2017$SR, log(R/SSB))
whk.2015 <- read.ASAP3.rep.file(rep.file="2015_HKW_UNIT_MOD.rep")
whk.2015$SR$Lnrs <- with(whk.2015$SR, log(R/SSB))
#######################################################################
# Step 2: Plot the time series of Recruitment, SSB, and log(R/SSB)
####################################################################### 
#jpeg('PlotSR_Fig1.jpg', width = 2500, height = 3000, res = 2500 / 5)
nyr <- length(whk.2022$SR$year)
x.range=with(whk.2022$SR, c(year[1],year[nyr]))
par(mfrow=c(3,1),mar=c(3,4,2,1)+0.1)
# Recruitment (note that the x-axis refers to the yearclass)
plot(R~year,data=whk.2015$SR,xlim=x.range,type="l",lwd=2,col="violet",
     bty="l",ylab="Recruits (millions)")
lines(R~year,data=whk.2017$SR,lwd=2,col="cyan")
lines(R~year,data=whk.2019$SR,lwd=2,col="orange")
lines(R~year,data=whk.2022$SR,lwd=2)
abline(h=median(whk.2022$SR$R),lty=2)
legend('topright',c("2015","2017","2019","2022"),title="Assess Year",
      lwd=2,col=c("violet","cyan","orange","black"),bty="n")
title(main="a. Recruitment (plotted by brood year)",adj=0)

# Spawning Stock Biomass
y.range=c(min(whk.2019$SR$SSB),max(whk.2022$SR$SSB))
plot(SSB~year,data=whk.2015$SR,xlim=x.range,ylim=y.range,type="l",
     bty="l",lwd=2,col="violet", ylab="SSB (kt)")
lines(SSB~year,data=whk.2017$SR,lwd=2,col="cyan")
lines(SSB~year,data=whk.2019$SR,lwd=2,col="orange")
lines(SSB~year,data=whk.2022$SR,lwd=2)
# add the SSBmsy proxy
points(whk.2022$SR$year[nyr],28.191,pch=16)
lines(rep(whk.2022$SR$year[nyr],2),c(22.616,35.424))
points(max(whk.2022$SR$year),whk.2022$Fref[5,4],pch=15)
points(max(whk.2019$SR$year),31.828,pch=16,col="orange")
points(max(whk.2019$SR$year),whk.2019$Fref[5,4],pch=15,col="orange")
points(max(whk.2017$SR$year),whk.2017$Fref[5,4],pch=15,col="cyan")
points(max(whk.2015$SR$year),whk.2015$Fref[5,4],pch=15,col="violet")
legend("bottomleft",c("SSB proxy","SSB msy"),pch=c(16,15),bty="n")
title(main="b. Spawning Stock Biomass",adj=0)

# log Recruits per Spawner
plot(log(R/SSB)~year,data=whk.2015$SR,xlim=x.range,type="l",
     bty="l",lwd=2,col="violet", ylab="log(R/SSB)")
lines(log(R/SSB)~year,data=whk.2017$SR,lwd=2,col="cyan")
lines(log(R/SSB)~year,data=whk.2019$SR,lwd=2,col="orange")
lines(log(R/SSB)~year,data=whk.2022$SR,lwd=2)
abline(h=mean(log(whk.2022$Recruits/whk.2022$SSB)),lty=2)
title(main="c. Productivity",adj=0)
#dev.off()
#######################################################################
# Step 3: Calculate the Ricker stock-recruitment relationships
####################################################################### 
library(dlm)
library(scales)

ricker <- function(obs.spawners,obs.log.r.s,years,vr=VR) {
Ric.ti <- lm(obs.log.r.s~obs.spawners)
#print(summary(Ric.ti))

#	time varying for intercept with fixed variance ratio
# this model estimates the variance of V directly, not the standard deviation
# warning message can occur with method="BFGS", if starting values aren't close to final est
## structure of the state-space matrices
mod <- dlmModReg(obs.spawners)
## state vector is [a and b]

build <- function(theta){
  mod$V[1,1] <- exp(theta[1])
  mod$W[1,1] <- vr*exp(theta[1])
  return(mod)
}

fit <- dlmMLE(obs.log.r.s, parm = log(0.1), build = build, method="BFGS", debug = TRUE)
mod_hat <- build(fit$par)

## filter and smooth
filt <- dlmFilter(obs.log.r.s, mod_hat)
smooth <- dlmSmooth(filt)

ahat <- dropFirst(smooth$s[,1])
bhat <- dropFirst(smooth$s[,2])
## uncertainty
state_var <- with(smooth, dlmSvd2var(U.S, D.S))
ase <- dropFirst(unlist(lapply(state_var, function(z){sqrt(z[1,1])})))

mult <- cbind(c(1, 0),
              c(1, -2),
              c(1, 2))

amat <- cbind(ahat, ase) %*% mult
matplot(years,amat,type="l",lty=c(1,2,2),col=1,ylab="log(R/S)")
# add the se(a) and b parameter estimates
pmat <- cbind(amat,ase,bhat)
dimnames(pmat)[[1]] <- as.character(years)
dimnames(pmat)[[2]] <- c("ahat","lbda","ubda","ase","bhat")
#predicted values
smooth.y<-dropFirst(smooth$s[,1])+obs.spawners*dropFirst(smooth$s[,2])
pred.s.recruit<-obs.spawners*exp(smooth.y)
pred.val <- data.frame(years,smooth.y,pred.s.recruit)
list(Ric.ti=Ric.ti,pmat=pmat,pred.val=pred.val)
}

VR <- 0.829        # variance ratio from multistock fit

# 2015 assessment
SSB <- whk.2015$SR$SSB
RPS <- whk.2015$SR$Lnrs
YRS <- whk.2015$SR$year
ric.2015 <- ricker(SSB,RPS,YRS)

# 2017 assessment
SSB <- whk.2017$SR$SSB
RPS <- whk.2017$SR$Lnrs
YRS <- whk.2017$SR$year
ric.2017 <- ricker(SSB,RPS,YRS)

# 2019 assessment
SSB <- whk.2019$SR$SSB
RPS <- whk.2019$SR$Lnrs
YRS <- whk.2019$SR$year
ric.2019 <- ricker(SSB,RPS,YRS)

# 2022 assessment
SSB <- whk.2022$SR$SSB
RPS <- whk.2022$SR$Lnrs
YRS <- whk.2022$SR$year
ric.2022 <- ricker(SSB,RPS,YRS)

# plot the a-values from each assessment on the same axes
#jpeg('Productivity_Fig3.jpg', width = 3500, height = 2500, res = 2500 / 5)
matplot(whk.2022$SR$year,ric.2022$pmat[,1:3],type="l",col=c(1,0,0),lwd=2,
        bty="l",xlab="Year",ylab="log(R/S)")
x <- with(whk.2022$SR, c(year,rev(year),year[1]))
y <- with(ric.2022, c(pmat[,2],rev(pmat[,3]),pmat[1,2]))
polygon(x,y,col=alpha("gray",0.5),border=NA)
# 2019 assessment
x <- with(whk.2019$SR, c(year,rev(year),year[1]))
y <- with(ric.2019, c(pmat[,2],rev(pmat[,3]),pmat[1,2]))
polygon(x,y,col=alpha("orange",0.25),border=NA)
# 2017 assessment
x <- with(whk.2017$SR, c(year,rev(year),year[1]))
y <- with(ric.2017, c(pmat[,2],rev(pmat[,3]),pmat[1,2]))
polygon(x,y,col=alpha("cyan",0.25),border=NA)
# 2015 assessment
x <- with(whk.2015$SR, c(year,rev(year),year[1]))
y <- with(ric.2015, c(pmat[,2],rev(pmat[,3]),pmat[1,2]))
polygon(x,y,col=alpha("violet",0.25),border=NA)
# superimpose the lines
lines(whk.2022$SR$year,ric.2022$pmat[,1],lwd=2)
lines(whk.2019$SR$year,ric.2019$pmat[,1],col="orange",lwd=2)
lines(whk.2017$SR$year,ric.2017$pmat[,1],col="cyan",lwd=2)
lines(whk.2015$SR$year,ric.2015$pmat[,1],col="violet",lwd=2)
legend('topright',c("2015","2017","2019","2022"),title="Assessment Year",
       ncol=2,lwd=2,col=c("violet","cyan","orange","black"),bty="n")
title(main="White Hake Productivity")
# note that we could add one-year projections as dots
#dev.off()
#######################################################################
# Step 4: Compare the goodness of fit for the Ricker models
####################################################################### 
years <- whk.2022$SR$year
# recruitment
#jpeg('RickerGoodnessofFits_Fig5.jpg', width = 2500, height = 3000, res = 2500 / 5)
par(mfrow=c(2,1),mar=c(2,4,2,1)+0.1)
toto <- predict(ric.2022$Ric.ti,se.fit=TRUE)
mult <- cbind(c(1, 0), c(1, -2), c(1, 2))
Ric.mat <- cbind(toto$fit,toto$se.fit) %*% mult
with(whk.2022$SR, plot(year,R,bty="l",xlab="Year",ylab="Recruits (millions)"))
Rec.mat <- exp(Ric.mat) * whk.2022$SR$SSB
x <- c(years,rev(years),years[1])
y <- c(Rec.mat[,2],rev(Rec.mat[,3]),Rec.mat[1,2])
polygon(x,y,col=alpha("gray",0.5),border=NA)
lines(years,Rec.mat[,1])
with(ric.2022$pred.val,lines(years,pred.s.recruit,col="blue",lwd=1))
lines(years,rep(median(whk.2022$SR$R),length(years)),col="red")
yr <- years[years > 1994]
y <- rep(median(whk.2022$SR$R[years>1994]),length(yr))
lines(yr,y,col="orange")
legend("topright",c("stationary","recent","Ricker","dlm"),lty=1,
       title="Model",col=c("red","orange","black","blue"),bty="n")
title(main="a. White Hake Recruitment", adj=0)

# per capita recruitment
with(whk.2022$SR,plot(year,Lnrs,bty="l",xlab="Year",ylab="log(R/SSB)"))
x <- c(years,rev(years),years[1])
y <- c(Ric.mat[,2],rev(Ric.mat[,3]),Ric.mat[1,2])
polygon(x,y,col=alpha("gray",0.5),border=NA)
lines(years,Ric.mat[,1])
with(ric.2022$pred.val,lines(years,smooth.y,col="blue",lwd=1))
y <- with(whk.2022$SR, rep(mean(log(R)),length(years)) - log(SSB))
lines(years,y,col="red")
y <- with(whk.2022$SR, rep(mean(log(R[years>1994])),length(yr)) - log(SSB[years>1994]))
lines(years[years>1994],y,col="orange")
legend("topleft",c("stationary","recent","Ricker","dlm"),lty=1,
       col=c("red","orange","black","blue"),bty="n")
title(main="b. Per-capita Recruitment", adj=0)
#dev.off()
#######################################################################
# Step 5: Plot the dynamic Ricker stock-recruitment relationships
####################################################################### 
#jpeg('DynamicRickerCurves_Fig4.jpg', width = 3500, height = 2500, res = 2500 / 5)
par(mfrow=c(1,1),mar=c(4,4,2,1)+0.1)
with(whk.2022$SR,plot(SSB,R,xlim=c(0,max(SSB)),ylim=c(0,max(R)),type="n",
  bty="l",xlab="SSB (kt)",ylab="Recruits (millions)"))
# color code the lines according to their productivity
resolution <- 101
# create a large array of Ricker curves to plot
x <- seq(0,40,by=0.2)
a <- seq(-1,0.58,length.out=20)
rec.mat <- matrix(nrow=length(x),ncol=20)
for (i in 1:20) {
  rec.mat[ ,i] <- x*exp(a[i]+ric.2022$pmat[1,5]*x)
}
matlines(x,rec.mat,col=colorRampPalette(c("red","blue"),space="Lab")(resolution)
  [as.numeric(cut(a,breaks=seq(-1,0.58,length.out=resolution+1),include.lowest=T))],
         lty=1,lwd=2)
# sort the points by their productivity in ric.2022$amat[,1]
rmat <- ric.2022$pmat[,1]
# color code the points according to their productivity
with(whk.2022$SR, points(SSB,R,col=colorRampPalette(c("red","blue"),space="Lab")(resolution)
  [as.numeric(cut(rmat,breaks=seq(-1,0.58,length.out=resolution+1),include.lowest=T))],pch=16))
title(main="Dynamic Ricker Curves")
#dev.off()
#######################################################################
# Step 6: Calculate the Beverton-Holt stock-recruitment relationships
####################################################################### 
# first plot the Ricker curves from each assessment as subplot a.
#jpeg('TimeInvariantModels_Fig2.jpg', width = 2500, height = 3000, res = 2500 / 5)
par(mfrow=c(2,1),mar=c(4,4,2,1)+0.1)
plot(R~SSB,data=whk.2015$SR,xlim=c(0,max(whk.2022$SR$SSB)),ylim=c(0,max(R)),
     bty="l",col="violet",xlab="SSB (kt)",ylab="Recruits (millions)")
parms <- coef(ric.2015$Ric.ti)
curve(x*exp(parms[1]+x*parms[2]),lwd=2,col='violet',add=T)
points(R~SSB,data=whk.2017$SR,col="cyan")
parms <- coef(ric.2017$Ric.ti)
curve(x*exp(parms[1]+x*parms[2]),lwd=2,col='cyan',add=T)
points(R~SSB,data=whk.2019$SR,col="orange")
parms <- coef(ric.2019$Ric.ti)
curve(x*exp(parms[1]+x*parms[2]),lwd=2,col='orange',add=T)
points(R~SSB,data=whk.2022$SR,col="black")
parms <- coef(ric.2022$Ric.ti)
curve(x*exp(parms[1]+x*parms[2]),lwd=2,col='black',add=T)
legend('topleft',c("2015","2017","2019","2022"),title="Assess Year",
       lwd=2,col=c("violet","cyan","orange","black"),bty="n")
title(main="a. Ricker Model",adj=0)

# 2015 assessment
plot(R~SSB,data=whk.2015$SR,xlim=c(0,max(whk.2022$SR$SSB)),ylim=c(0,max(R)),
     bty="l",col="violet",xlab="SSB (kt)",ylab="Recruits (millions)")
bh.2015 <- with(whk.2015$SR, glm(R/SSB~SSB,family=Gamma))
parms <- coef(bh.2015)
curve(x/(parms[1]+x*parms[2]),lwd=2,col='violet',add=T)

# 2017 assessment
points(R~SSB,data=whk.2017$SR,col="cyan")
bh.2017 <- with(whk.2017$SR, glm(R/SSB~SSB,family=Gamma))
parms <- coef(bh.2017)
curve(x/(parms[1]+x*parms[2]),lwd=2,col='cyan',add=T)

# 2019 assessment
points(R~SSB,data=whk.2019$SR,col="orange")
bh.2019 <- with(whk.2019$SR, glm(R/SSB~SSB,family=Gamma))
parms <- coef(bh.2019)
curve(x/(parms[1]+x*parms[2]),lwd=2,col='orange',add=T)

# 2022 assessment
points(R~SSB,data=whk.2022$SR,col="black")
bh.2022 <- with(whk.2022$SR, glm(R/SSB~SSB,family=Gamma))
parms <- coef(bh.2022)
curve(x/(parms[1]+x*parms[2]),lwd=2,col='black',add=T)
legend('topleft',c("2015","2017","2019","2022"),title="Assess Year",
       lwd=2,col=c("violet","cyan","orange","black"),bty="n")
title(main="b. Beverton-Holt Model",adj=0)
#dev.off()

# read the output of the time-varying BH model estimated with TMB
dynBH <- read.csv("dynBH.csv",header=TRUE)
amat <- as.matrix(dynBH[dynBH$X=="ln_alpha",2:3]) %*% mult
#jpeg('DynamicModelComparison_Fig6.jpg', width = 3500, height = 2500, res = 2500 / 5)
par(mfrow=c(1,1),mar=c(4,4,2,1)+0.1)
matplot(years,amat,type="l",bty="l",lty=c(1,2,2),col=0,xlab="Year",ylab="log(R/S)")
## add shading
x <- c(years,rev(years),years[1])
y <- c(amat[,2],rev(amat[,3]),amat[1,2])
polygon(x,y,col=alpha("cyan",0.5),border=NA)
# add the Ricker estimates
x <- with(whk.2022$SR, c(year,rev(year),year[1]))
y <- with(ric.2022, c(pmat[,2],rev(pmat[,3]),pmat[1,2]))
polygon(x,y,col=alpha("violet",0.5),border=NA)
# add the lines for both models
lines(years,amat[,1],type="l",col="cyan",lwd=2)
lines(years,ric.2022$pmat[,1],type="l",col="violet",lwd=2)
legend("topright",c("Ricker","Beverton-Holt"),lty=1,lwd=2,
       col=c("violet","cyan"),bty="n")
title(main="White Hake Productivity")
#dev.off()
#######################################################################
# Step 7: Plot the dynamic Beverton-Holt stock-recruitment relationships
####################################################################### 
#jpeg('DynamicBHCurves_Fig7.jpg', width = 3500, height = 2500, res = 2500 / 5)
par(mfrow=c(1,1),mar=c(4,4,2,1)+0.1)
with(whk.2022$SR,plot(SSB,xlim=c(0,max(SSB)),ylim=c(0,max(R)),type="n",
              bty="l", xlab="SSB (kt)",ylab="Recruits (millions)"))
# color code the lines according to their productivity
resolution <- 101
# create an array of Beverton-Holt curves to plot
x <- seq(0,40,by=0.2)
a <- seq(-1.2,0.58,length.out=20)
rec.mat <- matrix(nrow=length(x),ncol=20)
for (i in 1:20) {
  rec.mat[ ,i] <- x*exp(a[i])/(1+x/8.488)
}
matlines(x,rec.mat,col=colorRampPalette(c("red","blue"),space="Lab")(resolution)
         [as.numeric(cut(a,breaks=seq(-1.2,0.58,length.out=resolution+1),include.lowest=T))],
         lty=1,lwd=2)
# color code the points according to their productivity
with(whk.2022$SR, points(SSB,R,col=colorRampPalette(c("red","blue"),space="Lab")(resolution)
       [as.numeric(cut(amat[,1],breaks=seq(-1.2,0.58,length.out=resolution+1),include.lowest=T))],pch=16))
title(main="Dynamic Beverton-Holt Curves")
#dev.off()
#######################################################################
# Step 8: Compare the goodness of fit for the Beverton-Holt models
####################################################################### 
#jpeg('BHGoodnessofFits_Fig8.jpg', width = 2500, height = 3000, res = 2500 / 5)
par(mfrow=c(2,1),mar=c(2,4,2,1)+0.1)
# recruitment
with(whk.2022$SR, plot(year,R,bty="l",xlab="Year",ylab="Recruits (millions)"))
#year <- whk.2022$Year
BH.ti <- with(whk.2022$SR, SSB/(parms[1]+SSB*parms[2]))
lines(years,BH.ti)
BH.tv <- with(whk.2022$SR, exp(amat[,1])*SSB/(1+SSB/8.488))
lines(years,BH.tv,col="blue")
lines(years,rep(median(whk.2022$SR$R),length(years)),col="red")
yr <- years[years > 1994]
y <- rep(median(whk.2022$SR$R[years>1994]),length(yr))
lines(yr,y,col="orange")
legend("topright",c("stationary","recent","Bev-Holt","TMB"),lty=1,
       title="Model",col=c("red","orange","black","blue"),bty="n")
title(main="a. White Hake Recruitment",adj=0)
# confidence intervals on the dynamic B-H model are too wide to plot
# per capita recruitment
with(whk.2022$SR, plot(year,Lnrs,bty="l",xlab="Year",ylab="log(R/SSB)"))
lines(years,log(BH.ti/whk.2022$SR$SSB))
lines(years,log(BH.tv/whk.2022$SR$SSB),col="blue")
y <- with(whk.2022$SR,rep(mean(log(R)),length(years)) - log(SSB))
lines(years,y,col="red")
y <- with(whk.2022$SR, rep(mean(log(R[years>1994])),length(yr)) - log(SSB[years>1994]))
lines(years[years>1994],y,col="orange")
legend("topleft",c("stationary","recent","Bev-Holt","TMB"),lty=1,
       col=c("red","orange","black","blue"),bty="n")
title(main="b. Per-capita Recruitment",adj=0)
#dev.off()
#######################################################################
# Step 8: Compare the fits of the Ricker and Beverton-Holt models
####################################################################### 
with(whk.2022$SR,plot(SSB,Lnrs,xlim=c(0,max(SSB)),
      ylim=c(min(Lnrs),-log(parms[1])),xlab="SSB (kt)",ylab="log(R/SSB)"))
abline(reg=ric.2022$Ric.ti,col="violet",lwd=2)
curve(-log(parms[1]+x*parms[2]),from=0,to=max(SSB),col="cyan",lwd=2,add=TRUE)
abline(v=0,lty=3)
legend("topright",c("Ricker","Beverton-Holt"),col=c("violet","cyan"),lwd=2,bty="n")
#save.image(file="WhiteHake.RData")
