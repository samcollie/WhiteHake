# Task 3: Calculate Biological Reference Points
# Script to read and extract fields from ASAP3 dat and rep files
# Modified from "fish-delay_test.R" by Jeremy Collie on 5-Jun-23
# Modified from "Read.ASAP3.files.R" by Jeremy Collie on 25-Jun-23
# Modified by Jeremy Collie on 8-Jun-23 to Read.ASAP3.rep.file.R
#rm(list=ls())
library(viridisLite)
#library(dlm)
# if the life history list already exists, start on line 66
##################################################################################
# STEP 1: DATA IMPORTATION 
##################################################################################
setwd("C:/Users/Jerem/Documents/Research/NOAA_COCA/Stock Assessments/WhiteHake/Analyses")
#path=paste0('C:\\Users\\',Sys.info()['user'],'\\Dropbox\\NMFS Assessments\\dynamic programming\\')
#paste0(..., collapse) is equivalent to paste(..., sep = "", collapse), slightly more efficiently.
path <- "C:/Users/Jerem/Documents/Research/NOAA_COCA/R Scripts/"
# tmp=readLines(paste0(path,'2017_FLW_GB_VPA_ASAP.rep'))
# Source the function "Read.ASAP3.rep.file.R" when we get 2022 rep file
# readLines reads text from a connection as character text 
modif=dget(paste0(path,'Read.ASAP3.dat.file.R')) 
#dget creates an R object from a file
file=modif('2022_HKW_UNIT_FINAL_ASAP_REV.dat')
# get only the necessary variables
file=file$dat[c("n_years","year1","n_ages","maturity","fracyr_spawn","n_fleets","M","WAA_mats","CAA_mats")]
# weight at age in kg
# note that there are 3 WAA matrices corresponding to different times of the year
# index 1 for WAA of catch/discard of different fleets, 2 for SSB, 3 for 1_Jan_biomass
n_years=file$n_years
years=file$year1:(file$year1+file$n_years-1)
A=file$n_ages
ages=1:A                # note that west coast stocks start at age 0
maturity=file$maturity
M=file$M                # natural mortality matrix
fracyr_spawn=file$fracyr_spawn
WAA_catch=file$WAA_mats[[1]]  # mean weight at age in the catch in kg
WAA_SSB=file$WAA_mats[[2]]  # weight at age at the time of spawning (SSB)
WAA_B=file$WAA_mats[[3]] # weight at age at the start of the year (B)
Catch=file$CAA_mats[[1]][,10]*0.001  # Total Catch in kt
# 4-year mean weight at age was used for reference pts and short-term projections# Now get the remaining information from Run14.rep

# Now get the remaining information from Run14.rep
source("Read.ASAP3.rep.file.R")
whk.rep <- read.ASAP3.rep.file(rep.file="Run14.rep")
FCB <- whk.rep$FF           # note that we could use a more generic name
# selectivity comes from the rep file since it is a result
selectivity <- whk.rep$selec

# retrieve the stock-recruitment info saved in WhiteHake.RData
load("WhiteHake.RData")
stock_name <- whk.2022$ID[1]
SR <- whk.rep$SR         #note that SR has one less year
SR$Lnrs <- with(SR,log(R/SSB))     
SR$a <- ric.2022$pmat[,1]
# since we didn't save the standard error of a, calculate it from the CI
SR$se.a <- with(ric.2022, (pmat[,1]-pmat[,2])/2)
SR$b <- rep(-0.0643,n_years-1)   # could pass this value 
# note that SR ends in 2020 but the assessment ends in 2021
FCB$Catch <- Catch
FCB$SSB <- whk.rep$Biomass$SSB
units <- list(SSB="kt",Recruits="millions",Catch="kt",Fdef="fully recruited")
F40 <- whk.rep$Fref$F[4] 
Fmsy <- whk.rep$Fref$F[5]
SSBmsy <- whk.rep$Fref$SSBmsy[5]
MSY <- whk.rep$Fref$MSY[5]
refpt <- list(F35=NA,F40=F40,Fmsy=Fmsy,SSBmsy=SSBmsy,MSY=MSY)
SRpar <- whk.rep$SRparam$value
bev_par <- list(alpha=1/0.1807, beta=0.6385/0.1807,
          R0=SRpar[2]*0.001,S0=SRpar[3]*0.001,steepness=SRpar[4])
# proxy values SSBmsy=28.191,MSY=4.186
##################################################################################
# STEP 2: CREATE AND SAVE THE LIST FOR REFERENCE POINT CALCULATION 
##################################################################################
WHT_HAKE_NE <- list(n_years=n_years,year1=file$year1,ages=ages,M=M,
  fracyr_spawn=fracyr_spawn,maturity=maturity,n_fleets=file$n_fleets,
  WAA_catch=WAA_catch,WAA_SSB=WAA_SSB,selectivity=selectivity,SR=SR,
  units=units,refpt=refpt,bev_par=bev_par,FCB=FCB)
# save this list as an R object for future use
#save(WHT_HAKE_NE,file="WHT_HAKE_NE.RData")
load("WHT_HAKE_NE.RData")
# so far, so good
# need to backtrack to ensure that the required SR elements are saved

##################################################################################
# STEP 3: CALCULATE REFERENCE POINTS FOR TIME-INVARIANT RICKER MODEL
##################################################################################
# define the life-history parameters
attach(WHT_HAKE_NE)
SR <- SR              # data frame of time series
Y <- dim(SR)[1]       # total number of stock-recruitment pairs
avec <- SR$a          # vector of a values from time-varying model
se.a <- SR$se.a       # standard error of a values
b.iv <- SR$b[1]       # note that b is negative
A <- length(ages)     # number of ages
select <- as.matrix(selectivity)
M <- as.matrix(M)
FS <- fracyr_spawn
maturity <- as.matrix(maturity)
WAA_SSB <- as.matrix(WAA_SSB)
WAA_catch <- as.matrix(WAA_catch)
refpt <- refpt
bev_par <- bev_par
FCB <- FCB
detach(WHT_HAKE_NE)

SSB <- SR$SSB    
R <- SR$R
# average the four most recent years for the time-invariant model
ln_FM <- log(0.2)
ric.lm <- with(SR, lm(Lnrs ~ SSB))
Ra <- ric.lm$coefficients[1]   
Rb <- ric.lm$coefficients[2]     # note that Rb is negative
sd_obs=sd(ric.lm$residuals)
# note that Y is the penultimate year (need parentheses)
S <- colMeans(select[(Y-2):(Y+1), ])  
NM <- colMeans(M[(Y-2):(Y+1), ])
MA <- colMeans(maturity[(Y-2):(Y+1), ])
WS <- colMeans(WAA_SSB[(Y-2):(Y+1), ])
WC <- colMeans(WAA_catch[(Y-2):(Y+1), ])

# ref points at the equilibrium   
fun_ref_points=function(ln_FM,aval,BH=FALSE,optim=T){
  FM=exp(ln_FM)
  # for 1 recruit
  nb=1
  # how many individuals at age 2 to A-1
  for (i in 2:(A-1)){
    # fish number at the beginning of the year
    nb=c(nb,exp(-(NM[i-1]+S[i-1]*FM))*rev(nb)[1])
  }
  # termainal age number // demonstration per geometric progression
  nb=c(nb,exp(-(NM[A-1]+S[A-1]*FM))*rev(nb)[1]/(1-exp(-(NM[A]+S[A]*FM))))
  
  # spawner per recruit at the reproduction time, so partially dead (in tonnes)
  spr=sum(exp(-FS*(NM+S*FM))*nb*MA*WS)
  # Bervanov equation (in tonnes)
  ypr=sum(WC*nb*(1-exp(-(NM+S*FM)))*(S*FM/(NM+S*FM)))
  # yield at equilibrium
  
  Req <- ifelse(BH, (aval*spr-Rb)/spr, (-log(spr)-aval)/(Rb*spr))
  Yeq=ifelse(any(c(Req,ypr)<0),0,Req*ypr)
  # changed to no longer return nb
  if(optim==T){return(-Yeq)}else{
    return(list(Fmsy=FM,MSY=Yeq,Bmsy=spr*Req,Rmsy=Req,spr=spr,ypr=ypr))
  }
}

# what is the F at msy
ln_Fmsy=optim(log(0.1),fun_ref_points,aval=Ra,method = 'L-BFGS-B')$par
# why is Ra reversed?  Is this simply to chose the most recent value?
# msy ref points
Ric_ref_p=fun_ref_points(ln_Fmsy,aval = Ra,optim = F)

# virgin ref points
virgin_ref_p=fun_ref_points(-1e16,aval = Ra,optim = F)
# note that individuals pile up in the plus group
par(mfrow=c(1,1),mar=c(4,4,2,1)+0.1)
plot(SSB,R,ylim=c(0,1.1*max(R)),xlim=c(0,1.1*max(c(virgin_ref_p$Bmsy,SSB))),
       col=viridis(nrow(SR)),yaxs='i',xaxs='i',pch=16,type="b")
xx=seq(0,1.1*max(c(virgin_ref_p$Bmsy,SSB)),length.out=100)
lines(xx,xx*exp(rev(Ra)[1]+Rb*xx),col="red")
lines(xx,xx*exp(rev(Ra)[1]+Rb*xx+sd_obs^2/2),col="green")
#lines(xx,xx*exp(R_old[1]+R_old[2]*xx+sd_old^2/2),lty=2)
#variance was included for the stochastic case
abline(v=Ric_ref_p$Bmsy,lty=3)
abline(0,virgin_ref_p$Rmsy/virgin_ref_p$Bmsy,lty=2)
abline(v=virgin_ref_p$Bmsy,lty=3)

# These calculations were checked with CheckReferencePoints.R 
# when complete apply to Gulf of Maine cod for comparison

##################################################################################
# STEP 4: CALCULATE REFERENCE POINTS FOR TIME-INVARIANT B-H MODEL
##################################################################################
# define the Beverton-Holt parameters
Ra <- bev_par$alpha
Rb <- bev_par$beta
# this B-H formulation differs from the one used for estimation

# what is the F at msy
ln_Fmsy=optim(log(0.1),fun_ref_points,aval=Ra,BH=TRUE,method = 'L-BFGS-B')$par
# why is Ra reversed?  Is this simply to chose the most recent value?
# msy ref points
Bev_ref_p=fun_ref_points(ln_Fmsy,aval = Ra,BH=TRUE,optim = F)

# virgin ref points
virgin_ref_p=fun_ref_points(-1e16,aval = Ra,BH=TRUE,optim = F)
# note that individuals pile up in the plus group
# SR <- WHT_HAKE_NE$SR
plot(SSB,R,ylim=c(0,1.1*max(R)),xlim=c(0,1.1*max(c(virgin_ref_p$Bmsy,SSB))),
     col=viridis(nrow(SR)),yaxs='i',xaxs='i',pch=16,type="b")
xx=seq(0,1.1*max(c(virgin_ref_p$Bmsy,SSB)),length.out=100)
lines(xx,xx*Ra/(Rb+xx),col="red")

abline(v=Bev_ref_p$Bmsy,lty=3)
abline(0,virgin_ref_p$Rmsy/virgin_ref_p$Bmsy,lty=2)
abline(v=virgin_ref_p$Bmsy,lty=3)

##################################################################################
# STEP 5: CALCULATE REFERENCE POINTS FOR TIME-VARYING RICKER MODEL
##################################################################################
# define the stock-recruitment parameters
Ra <- avec          # vector of a values
sd_obs <- se.a      # standard error of a values
Rb <- b.iv          # note that Rb is negative

# put the values that change each year (j) inside a function
ref.pts <- function(j) {
  S <- select[j, ]            
  NM <- M[j, ]
  MA <- maturity[j,]
  WS <- WAA_SSB[j,]
  WC <- WAA_catch[j,]
  # what is the F at msy 
  ln_Fmsy=optim(log(0.1),fun_ref_points,aval=Ra[j],method = 'L-BFGS-B')$par
  ln_Fmsy
}
ln_Fmsy <- sapply(1:Y,ref.pts)

# msy ref points
msy.pts <- function(j) {
  S <- select[j, ]            
  NM <- M[j, ]
  MA <- maturity[j,]
  WS <- WAA_SSB[j,]
  WC <- WAA_catch[j,]
  # what are the reference points at msy 
  MSY_ref_p=fun_ref_points(ln_Fmsy[j],aval = Ra[j],optim = F)
  MSY_ref_p
}
MSY_ref_p <- sapply(1:Y,msy.pts)
MSY_ref_mat <- matrix(unlist(MSY_ref_p),nrow=6)

# virgin ref points
virgin.pts <- function(j) {
  S <- select[j, ]            
  NM <- M[j, ]
  MA <- maturity[j,]
  WS <- WAA_SSB[j,]
  WC <- WAA_catch[j,]
  # what are the reference points at msy 
  virgin_ref_p=fun_ref_points(-1e16,aval = Ra[j],optim = F)
  virgin_ref_p
}
virgin_ref_p <- sapply(1:Y,virgin.pts)

# plot the Ricker model for the first and last years
plot(SSB,R,ylim=c(0,1.1*max(R)),xlim=c(0,1.1*max(c(virgin_ref_p$Bmsy,SSB))),
     col=viridis(nrow(SR)),yaxs='i',xaxs='i',pch=16,type="b")
xx=seq(0,1.1*max(c(virgin_ref_p$Bmsy,SSB)),length.out=100)
j <- 1
lines(xx,xx*exp(Ra[j]+Rb*xx),col="purple4")
abline(v=MSY_ref_p[,j]$Bmsy,lty=3,col="purple4")
abline(0,virgin_ref_p[,j]$Rmsy/virgin_ref_p[,j]$Bmsy,lty=2,col="purple4")
abline(v=virgin_ref_p[,j]$Bmsy,lty=3,col="purple4")
j <- Y
lines(xx,xx*exp(Ra[j]+Rb*xx),col="yellow")
abline(v=MSY_ref_p[,j]$Bmsy,lty=3,col="yellow")
abline(0,virgin_ref_p[,j]$Rmsy/virgin_ref_p[,j]$Bmsy,lty=2,col="yellow")
abline(v=virgin_ref_p[,j]$Bmsy,lty=3,col="yellow")

##################################################################################
# STEP 6: PLOT THE REFERENCE POINTS
##################################################################################
#jpeg('ref_points_Fig9.jpg', width = 2500, height = 3000, res = 2500 / 5)
par(mfrow=c(3,1),mar=c(2,4,1,1)+0.1)
# F and Fmsy
years <- FCB$year
with(FCB, plot(year,F,type="b",ylim=c(0,max(F)),xlab="Year",ylab="Fmsy",bty="l"))
points(max(years),0.104,pch=20)          # retrospective adjustment
lines(SR$year,MSY_ref_mat[1, ],lwd=2,col="violet")
# add other reference points for the terminal four years
yr4 <- with(SR, (year[Y]-2):(year[Y]+1))
lines(yr4,rep(Ric_ref_p$Fmsy,4),lwd=2,col="blue")  # Ricker model
lines(yr4,rep(Bev_ref_p$Fmsy,4),lwd=2,col="cyan")  # B-H model
lines(yr4,rep(refpt$F40,4),lwd=2,col="red")        # F40% proxy
points(max(years),refpt$Fmsy,pch=15)               # from assessment     
legend("topright",c("Ffull","dlm","Ricker","B-H","F40%"),lwd=c(1,2,2,2,2),
  col=c("black","violet","blue","cyan","red"),bty="n",pch=c(1,rep(NA,4)))
text(1963,0.9,"a.")

# plot SSB as timeseries
with(FCB, plot(year,SSB,type="b",ylim=c(0,max(SSB)),xlab="Year",ylab="Bmsy (kt)",bty="l"))
lines(rep(max(years),2),c(FCB$SSB[length(years)],19.497))
points(max(years),19.497,pch=20)          # retrospective adjustment
lines(SR$year,MSY_ref_mat[3, ],lwd=2,col="violet")
# add other reference points for the terminal four years
lines(yr4,rep(Ric_ref_p$Bmsy,4),lwd=2,col="blue") # Ricker model
lines(yr4,rep(Bev_ref_p$Bmsy,4),lwd=2,col="cyan") # B-H model
lines(yr4,rep(28.191,4),lwd=2,col="red")          # SSB% proxy
points(max(years),refpt$SSBmsy,pch=15)            # from assessment 
legend(1990,42,c("SSB","dlm","Ricker","B-H","SSB40%"),lwd=c(1,rep(2,4)),
 col=c("black","violet","blue","cyan","red"),bty="n",pch=c(1,rep(NA,4)))
text(1963,40,"b.")

# plot MSY as timeseries with total catch for comparison
with(FCB, plot(year,Catch,type="b",ylim=c(0,max(Catch)),xlab="Year",ylab="MSY (kt)",bty="l"))
lines(SR$year,MSY_ref_mat[2,],ylim=c(0,max(MSY_ref_mat[2,])),type="l",lwd=2,
     col="violet",xlab="Year",ylab="MSY (kt)")
# add other reference points for the terminal four years
lines(yr4,rep(Ric_ref_p$MSY,4),lwd=2,col="blue")  # Ricker model
lines(yr4,rep(Bev_ref_p$MSY,4),lwd=2,col="cyan")  # B-H model
lines(yr4,rep(4.186,4),lwd=2,col="red")           # proxy value
points(max(years),Bev_ref_p$MSY,pch=15)           # from assessment 
legend(2000,11,c("Catch","dlm","Ricker","B-H","MSY proxy"),lwd=c(1,2,2,2,2),
 col=c("black","violet","blue","cyan","red"),bty="n",pch=c(1,rep(NA,4)))
text(1963,10,"c.")
#dev.off()
# ----------------------------------------------------------------------
# save the original reference points function, in case we need it again.
# ref points at the equilibrium   
fun_ref_points=function(ln_FM,aval,optim=T){
  FM=exp(ln_FM)
  # for 1 recruit
  nb=1
  # how many individuals at age 2 to A-1
  for (i in 2:(A-1)){
    # fish number at the beginning of the year
    nb=c(nb,exp(-(NM[i-1]+S[i-1]*FM))*rev(nb)[1])
  }
  # termainal age number // demonstration per geometric progression
  nb=c(nb,exp(-(NM[A-1]+S[A-1]*FM))*rev(nb)[1]/(1-exp(-(NM[A]+S[A]*FM))))
  
  # spawner per recruit at the reproduction time, so partially dead (in tonnes)
  spr=sum(exp(-FS*(NM+S*FM))*nb*MA*WS)
  # Bervanov equation (in tonnes)
  ypr=sum(WC*nb*(1-exp(-(NM+S*FM)))*(S*FM/(NM+S*FM)))
  # yield at equilibrium
  
  Req=(-log(spr)-aval)/(Rb*spr)
  Yeq=ifelse(any(c(Req,ypr)<0),0,Req*ypr)
  # omit(nb from the return list)
  if(optim==T){return(-Yeq)}else{
    return(list(Fmsy=FM,MSY=Yeq,Bmsy=spr*Req,Rmsy=Req,spr=spr,ypr=ypr))
  }
}
